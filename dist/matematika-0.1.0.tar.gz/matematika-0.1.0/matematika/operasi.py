def penjumlahan(a: int, b: int) -> int:
    return a + b

def pengurangan(a: int, b: int) -> int:
    return a - b

def perkalian(a: int, b: int) -> int:
    return a * b

def pembagian(a: float, b: float) -> float:
    return a / b