def hello() -> str:
    return "Hello World!"